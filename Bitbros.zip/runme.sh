#!/bin/sh
python3 351crawler.py $1 $2 $3